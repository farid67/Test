#include "test.h"

void affiche()
{
	printf("Hello World!\n");
}
