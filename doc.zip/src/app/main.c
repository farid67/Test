#include "test.h"

int main (int argc, char *argv[])
{
	affiche();
	return 0;
}
